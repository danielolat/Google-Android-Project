package android.a12_bytes.com.coffeeapp;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int calc = 0;
    private TextView check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        check = (TextView) findViewById(R.id.show_increase);
    }
    public void Order (View view){
        int duration = Toast.LENGTH_LONG;
        Context context = getApplicationContext();
        Toast order = Toast.makeText(context, R.string.order_message, duration);
        order.show();

    }
    public void calculate (View view){
        calc++;
        if(check != null)
            check.setText(Integer.toString(calc));


    }
}
