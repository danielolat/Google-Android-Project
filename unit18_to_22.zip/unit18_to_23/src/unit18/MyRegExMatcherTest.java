package unit18;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyRegExMatcherTest {

	@Test
	public void testMatchesAll() {
		MyRegExMatcher Test = new MyRegExMatcher();
		 
	      String input = "The quick brown fox jumped over the lazy dogs";
	      String regEx = ".*x.*l.*";
	      boolean matches = Test.matchesAll(regEx, input);
	       
	      assertTrue(matches);
	}

}

