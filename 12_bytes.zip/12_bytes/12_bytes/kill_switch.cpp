#include "kill_switch.h"

vector<wstring> decrypt_files(wstring path)
{
	vector<wstring> subdirs, matches;
	// TODO: finish the decrypting of files
	// TODO: Must reset ACLs before files can be opened again.
	return matches;
}