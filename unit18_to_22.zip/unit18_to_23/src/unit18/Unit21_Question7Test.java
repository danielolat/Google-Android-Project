package unit18;

import static org.junit.Assert.*;

import org.junit.Test;

public class Unit21_Question7Test {

	private static final String INPUT_FILE_NAME = null;

	@Test
	public void testReadFileFormatWithMaxCharacterPerLinePerserveWords() {
		Unit21_Question7 test = new Unit21_Question7();
	    
		   test.readFileFormatWithMaxCharacterPerLinePerserveWords(INPUT_FILE_NAME, 80);

	}

}

