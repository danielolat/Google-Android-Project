import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;


public class Question2 {
	public int[] intInit() {
		   int[] Array = {
		      1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 27, 29
		   };
		   Logger l = Logger.getLogger(Question2.class.getName());
		   for (int number : Array) {
		   l.info("Number: " + number);
		   }
		  return Array;
		  }
	public List<Object> problem6() {
		   List<Object> Number6 = new ArrayList<>();
		   Number6.add(32);
		   Number6.add("This is a string");
		   Number6.add(Integer.valueOf(238));
		   Number6.add(-410);		    
		   return Number6;
		}
}

