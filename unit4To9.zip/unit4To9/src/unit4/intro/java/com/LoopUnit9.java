package unit4.intro.java.com;

import java.util.logging.Logger;

public class LoopUnit9 {
	private static final Logger log = Logger.getLogger(LoopUnit9.class.getName());
    
	//for question10
	   public void loop() {
	      for (int i = 3, IN = 1; IN <= 6; i++, IN++) {
	         log.info("number of loop " + IN + ", value: " + i);
	      }
	     	      
	   }

}
