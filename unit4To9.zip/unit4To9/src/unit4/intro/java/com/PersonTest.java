package unit4.intro.java.com;

import static org.junit.Assert.*;

import org.junit.Test;

public class PersonTest {

	@Test
	public void testGetFullName() {
		Person p = new Person("Daniel", "Olatoye", "Daniel", 18, 79, 75, "Black", "MALE");
	       
	      String fullName = p.getFullName();
	       
	      assertEquals("Daniel Olatoye Daniel", fullName);
	}

}
