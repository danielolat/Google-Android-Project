package unit18;

import static org.junit.Assert.*;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.logging.Logger;

import org.junit.Test;

public class ContainerTest {

	@Test
	public void testContainer() {
		 private static final Logger log = Logger.getLogger(ContainerTest.class.getName());
		      Container container = new Container("Name");
		      String file = "Container.ser";
		      try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(file))) {
		         outputStream.writeObject(container);
		      } catch (IOException e) {
		         log.severe("IOException occurred: " + e.getLocalizedMessage());
		         e.printStackTrace();
		      }
		   }
	}

