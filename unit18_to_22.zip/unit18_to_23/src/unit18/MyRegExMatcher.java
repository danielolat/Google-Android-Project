package unit18;

public class MyRegExMatcher {
	public boolean matchesAll(String regex, String input) {
	      boolean RegEx = false;
//	      input = "The quick brown fox jumped over the lazy dogs";
//	      regex = ".*x.*l.*";
	      return RegEx;
	   }
}
