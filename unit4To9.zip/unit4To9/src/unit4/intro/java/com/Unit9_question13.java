package unit4.intro.java.com;

import java.util.logging.Logger;

public class Unit9_question13 {
	private static final Logger log = Logger.getLogger(Unit9_question13.class.getName());
	 
	   public void problem13() {
	      for (int i = 0, IN = 1; i < 10; i++, IN++) {
	         if (IN == 4 || IN == 5 || IN == 9) {
	            log.info("number of loops " + IN + " Missed");
	            continue;
	         }
	         log.info("number of loops " + IN + ", value: " + i);
	      }
	   }
}


