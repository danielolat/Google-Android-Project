package unit18;

public enum EyeColor {
	   BLUE("Blue"),
	   GREEN("Green"),
	   BROWN("Brown"),
	   GRAY("Gray"),
	   GOLD("Gold"),
	   BLACK("Black");
	    
	   private String Type;
	    
	   private EyeColor(String Type) {
	      this.Type = Type;
	   }
	    
	   public String getColor() {
	      return Type;
	   }
}



