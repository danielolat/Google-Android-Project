#include <vector>

using namespace std;

vector<wstring> decrypt_files(wstring path);

