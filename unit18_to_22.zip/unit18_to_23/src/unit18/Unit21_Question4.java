package unit18;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;


public class Unit21_Question4 {
	public String readFile(String fileName) {
	    
		   String read;
		   StringBuilder sb = new StringBuilder();
		    
		   File file = new File(fileName);
		   int lineNumber = 0;
		   try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)))) {
		      String line = reader.readLine();
		      while (line != null) {
		         sb.append(line);
		         sb.append('\n');
		         line = reader.readLine();
		      }
		   } catch (IOException e) {
		      log.severe("IOException occurred: " + e.getLocalizedMessage());
		   }
		    
		   read = sb.toString();
		   log.info("File contents:\n" + read);
		    
		   return read;
		}
	public void writeFile(String fileName, String fileContents) {
	    
		   File file = new File(fileName);
		    
		   try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)))) {
		      writer.write(fileContents);
		   } catch (IOException e) {
		      log.severe("IOException occurred: " + e.getLocalizedMessage());
		   }
	}
}
