package unit18;

import java.util.logging.Logger;

public class Hello {
	private static final Logger log = Logger.getLogger(Hello.class.getName());
    
	   interface HelloCallback {
	      void sayHello(String whatToSay);
	   }
	    
	   public void talk(HelloCallback helloCallback) {
	      helloCallback.sayHello("Hello, world (how original :/)...");
	   }
	 
	   public static void main(String[] args) {
	      //my Answer:
		   
		   Hello hello = new Hello();
	       
	      hello.talk(new HelloCallback() {
	 
	         @Override
	         public void sayHello(String whatToSay) {
	            log.info("This implementation says: " + whatToSay);
	         }
	          
	      });
	   }
}
