package com.intro.to.java.org;

/*
 * Implementation of the Unit6 Junit Test Case
 */

import static org.junit.Assert.assertEquals;

import java.util.logging.Logger;

import org.junit.Test;

public class TestPerson {
	@Test
	public void test() {
			String name = "DANIEL"; 
			int age = 20; 
			int height = 6; 
			int weight = 65; 
			String eyeColor = "BROWN"; 
			String gender = "MALE";
			Logger l = Logger.getLogger(TestPerson.class.getName());
			Person p = new Person(name, age, height, weight, eyeColor, gender);	
			l.info("Name: " + p.getName());
			l.info("Age: " + p.getAge());
			l.info("Height: " + p.getHeight());
			l.info("Weight: " + p.getWeight());
			l.info("Eye Color: " + p.getEyeColor());
			l.info("Gender: " + p.getGender()); 
			assertEquals(name, p.getName()); 
			assertEquals(age, p.getAge()); 
			assertEquals(height, p.getHeight()); 
			assertEquals(weight, p.getWeight());
			assertEquals(eyeColor, p.getEyeColor());
			assertEquals(gender, p.getGender()); 
			
		}

}
