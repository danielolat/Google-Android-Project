import static org.junit.Assert.*;

import java.awt.List;

import org.junit.Test;


public class Question2_ListTest {

	@Test
	public void testProblem6() {
		Question2 test = new Question2();
			    
		java.util.List<Object> Number6 = test.problem6();
			    
		assertEquals(32, Number6.get(0));
		assertEquals("This is a string", Number6.get(1));
		assertEquals(Integer.valueOf(238), Number6.get(2));
		assertEquals(-410, Number6.get(3));
	}

}

