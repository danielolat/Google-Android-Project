package unit4.intro.java.com;
import java.util.logging.Logger;

public class Person {
	   private String name;
	   private String lastName;
	   private String firstName;
	   private int age;
	   private int height;
	   private int  weight;
	   private String eyeColor;
	   private String gender;
	 
	   public Person(String name,String firstName,String lastName, int age, int height, int weight, String eyeColor,
			String gender) {
		   this.firstName = firstName;
		   this.lastName = lastName;
		   this.age = age;
		   this.height = height;
		   this.weight = weight;
		   this.eyeColor = eyeColor;
		   this.gender = gender;
	}
	/*
	 * Implementing the derived method of concat() for unit7 
	 */
	   
	public String getFullName(){
		return getFirstName() + " " + getLastName();
	}
	public String getLastName() {
	      return lastName;
	   }
	 
	   public void setLastName(String lastName) {
	      this.lastName = lastName;
	   }
	 
	   public String getFirstName() {
	      return firstName;
	   }
	 
	   public void setFirstName(String firstName) {
	      this.firstName = firstName;
	   }
	public String getName() { return name; }
	   public void setName(String value) { name = value; }
	   
	   /* Unit4 Question5
	    * Creating the getter and setter method
	    */
	   public int getAge(){
		   return age; 
	   }
	   public void setAge(int value){
		   age = value; 
	   }
	   public int getHeight(){
		   return height; 
	   }
	   public void setHeight(int value){
		   height = value; 
	   }
	   public int getWeight() { 
		   return weight; 
	   }
	   public void setWeight(int value){
		   weight = value; 
	   }
	   public String getEyeColor(){
		   return eyeColor; 
	   }
	   public void setEyeColor(String value){
		   eyeColor = value; 
	   }
	   public String getGender(){
		   return gender; 
	   }
	   public void setGender(String value){
		   gender = value; 
	   }
	   /*Unit6 Question4
	    *  implementing the toString() method on class Person
	    */
	   public String toString(){
		   String Tstring = "Name: " + getName() + ", " +
		   "Height: " + getHeight() + ", " +
		   "Weight: " + getWeight() + ", " +
		   "Eye Color: " + getEyeColor() + ", " +
		   "Gender: " + getGender();
		   return Tstring;
	   }
	}

