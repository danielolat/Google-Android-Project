package com.intro.to.java.org;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.logging.Logger;

import org.junit.Test;

public class EmployeeTest {

	@Test
	public void yetAnotherTest(){
		Logger l = Logger.getLogger(Employee.class.getName()); 
		Employee employee1 = new Employee("Daniel", 20, 175, 80, "BROWN", "MALE"); 
		employee1.setName("J Smith");
		Employee employee2 = new Employee("Daniel", 20, 175, 80, "BROWN", "MALE");
		employee2.setName("J Smith");
		l.info("Q: employee1 == employee2? A: " +(employee1 == employee2)); 
		l.info("Q: employee1.equals(employee2)? A: " +employee1.equals(employee2)); 
		
	}
}
