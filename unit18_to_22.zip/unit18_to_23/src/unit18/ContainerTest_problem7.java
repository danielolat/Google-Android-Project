package unit18;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.logging.Logger;

import org.junit.Test;

public class ContainerTest_problem7 {
	private static final 
	Logger log = Logger.getLogger(ContainerTest.class.getName());
	 
	@Test
	public void testContainer_problem7() {
		Container container = new Container("Some name");
	      String file = "Container.ser";
	      // Now read the file back in
	      try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(file))) {
	         container = (Container)inputStream.readObject();
	         assertEquals("Some name", container.getName());
	         assertEquals("Contained:Some name", container.getContained().getName());
	      } catch (IOException e) {
	         log.severe("IOException occurred: " + e.getLocalizedMessage());
	         e.printStackTrace();
	      } catch (ClassNotFoundException e) {
	         log.severe("ClassNotFoundException occurred: " + e.getLocalizedMessage());
	         e.printStackTrace();
	      }
	   }
	}


