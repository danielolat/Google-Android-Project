package unit18;

public class Question3 {
	private static final Logger log = Logger.getLogger(Outer.class.getName());
    
	   public void setInner(Inner inner) {
	      this.inner = inner;
	   }
	 
	   private Inner inner;
	    
	   public Inner getInner() {
	 
	      return inner;
	   }
	 
	   private class Inner {
	   }
	    
	   public static void main(String[] args) {
	      Outer outer = new Outer();
	      Inner inner = new Outer.Inner();
	      outer.setInner(inner);
	      log.info("Outer/Inner: " + outer.hashCode() + "/" + outer.getInner().hashCode());
	   }
	 /*
	  * The line 22 is in error because it is wrong to instantiate a nested class using an enclosing class reference.
	  * it could be corrected by typing: Inner inner = outer.new Inner();
	  */
}
