package unit4.intro.java.com;

import java.util.logging.Logger;

public class Unit9_whileLoop {
	private static final Logger log = Logger.getLogger(Unit9_whileLoop.class.getName());
	 
	   public void problem11() {
	      int aa = 3;
	      int IN = 1;
	       
	      while (IN <= 6) {
	         log.info("Iteration# " + IN + ", Loop variable: " + aa);
	         aa++;
	         IN++;
	      }
	   }
}
