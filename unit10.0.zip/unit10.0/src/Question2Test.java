import static org.junit.Assert.*;

import org.junit.Test;


public class Question2Test {

	@Test
	public void testIntInit() {
		Question2 testclass = new Question2 ();
		   int[] intArray = testclass.intInit();
		   assertEquals(intArray[0], 1);
		   assertEquals(intArray[1], 2);
		   assertEquals(intArray[2], 3);
		   assertEquals(intArray[3], 5);
		   assertEquals(intArray[4], 7);
		   assertEquals(intArray[5], 11);
		   assertEquals(intArray[6], 13);
		   assertEquals(intArray[7], 17);
		   assertEquals(intArray[8], 19);
		   assertEquals(intArray[9], 23);
		   assertEquals(intArray[10], 27);
		   assertEquals(intArray[11], 29);
	}

}
