package unit14;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Logger;
 
public class Question3 {

	private static final Logger l = Logger.getLogger(Question3.class.getName());
    
	   public void hierarchyExample() {
	      File file = new File("file.txt");
	       
	      BufferedReader bufferedReader = null;
	       
	      try {
	         bufferedReader = new BufferedReader(new FileReader(file));
	         String line = bufferedReader.readLine();
	         while (line != null) {
	            // Read the line
	         }
	      } catch (IOException e) {
	         l.severe(e.getMessage());
	      } catch (FileNotFoundException e) {
	 
	         l.severe(e.getMessage());
	      } catch (Exception e) {
	         l.severe(e.getMessage());
	      }
	      /*
	       * The code will not compile because the catch block for FileNotFoundException 
	       * should come before the catch block for IOException, because 
	       * FileNotFoundException is a subclass of IOException. 
	       * this is meant to be placed after, and the code will not run. 
	       */
	   }
}
