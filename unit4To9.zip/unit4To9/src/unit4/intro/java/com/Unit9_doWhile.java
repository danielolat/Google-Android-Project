package unit4.intro.java.com;

import java.util.logging.Logger;

public class Unit9_doWhile {
	private static final Logger log = Logger.getLogger(Unit9_doWhile.class.getName());
	 
	   public void problem12() {
	      int i = 3;
	      int IN = 1;
	       
	      do {
	         log.info("Iteration# " + IN + ", Loop variable: " + i);
	         i++;
	         IN++;
	      } while (IN <=6);
	   }
}


