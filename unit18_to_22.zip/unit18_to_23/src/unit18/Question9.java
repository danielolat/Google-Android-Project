package unit18;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Question9 {
	public boolean matchesAll(String regex, String input) {
      boolean ret = false;
       
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(input);
       
      ret = matcher.matches();
      return ret;
   }
}
