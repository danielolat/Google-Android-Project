package unit18;

import static org.junit.Assert.*;

import org.junit.Test;

public class Unit21_Question4Test {
	private static final 
	String INPUT_FILE_NAME = "./lorem.txt";

	@Test
	public void testReadFile() {
		Unit21_Question4 test = new Unit21_Question4();
		test.readFile(INPUT_FILE_NAME);
		
	}
	@Test
	public void testWriteFile() {
	   String fileName = "./lorem2.txt";
	    
	   Unit21_Question4 classUnderTest = new Unit21_Question4();
	    
	   String fileContents = classUnderTest.readFile(INPUT_FILE_NAME);
	   classUnderTest.writeFile(fileName, fileContents);
	}

}
