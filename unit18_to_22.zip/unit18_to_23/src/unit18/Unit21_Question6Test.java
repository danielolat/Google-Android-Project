package unit18;

import static org.junit.Assert.*;

import org.junit.Test;

public class Unit21_Question6Test {

	private static final 
	String INPUT_FILE_NAME = "./lorem.txt";
	@Test
	public void testReadFileFormatWithMaxCharactersPerLine() {
		Unit21_Question6 test = new Unit21_Question6();
		   test.readFileFormatWithMaxCharactersPerLine(INPUT_FILE_NAME, 80);
	}

}
